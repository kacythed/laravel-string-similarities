<?php

namespace Atomescrochus\StringSimilarities;

use Illuminate\Support\ServiceProvider;

class StringSimilaritiesServiceProvider extends ServiceProvider
{
    /**
     * Perform post-registration booting of services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register any package services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
